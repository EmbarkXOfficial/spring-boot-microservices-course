package com.embarkx.jobms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
